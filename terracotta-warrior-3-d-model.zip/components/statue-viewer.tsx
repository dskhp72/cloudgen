'use client'

import { Suspense, useMemo, useState } from 'react'
import { Canvas, useLoader } from '@react-three/fiber'
import { ContactShadows, Environment, OrbitControls, Html, useProgress } from '@react-three/drei'
import { MTLLoader, OBJLoader } from 'three-stdlib'
import * as THREE from 'three'
import { Info, Maximize2, Pause, Play, RotateCcw, Sun, Moon } from 'lucide-react'

function Loader() {
  const { progress } = useProgress()
  return <Html center><div className="loading-label">Loading artifact {Math.round(progress)}%</div></Html>
}

function Statue({ autoRotate, daylight }: { autoRotate: boolean; daylight: boolean }) {
  const materials = useLoader(MTLLoader, '/models/statue.mtl')
  const object = useLoader(OBJLoader, '/models/statue.obj', (loader) => {
    materials.preload()
    loader.setMaterials(materials)
  })
  const model = useMemo(() => {
    const clone = object.clone()
    const box = new THREE.Box3().setFromObject(clone)
    const center = box.getCenter(new THREE.Vector3())
    const size = box.getSize(new THREE.Vector3())
    const scale = 3.3 / Math.max(size.x, size.y, size.z)
    clone.position.set(-center.x * scale, -center.y * scale + 0.02, -center.z * scale)
    clone.scale.setScalar(scale)
    clone.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        child.castShadow = true
        child.receiveShadow = true
      }
    })
    return clone
  }, [object])

  return (
    <>
      <primitive object={model} />
      <OrbitControls makeDefault enableDamping dampingFactor={0.07} minDistance={2.1} maxDistance={6.5} autoRotate={autoRotate} autoRotateSpeed={0.75} target={[0, 1.55, 0]} />
      <ambientLight intensity={daylight ? 1.7 : 0.55} color={daylight ? '#fff4dc' : '#d6b28c'} />
      <directionalLight castShadow position={[3, 5, 4]} intensity={daylight ? 3.5 : 2.1} color={daylight ? '#fff2d4' : '#ffc48b'} shadow-mapSize={[2048, 2048]} />
      <spotLight position={[-4, 4, 1]} intensity={daylight ? 1.2 : 4} angle={0.42} penumbra={0.8} color={daylight ? '#a8c9ff' : '#d85b32'} castShadow />
      {!daylight && <pointLight position={[2, 1.2, -2]} intensity={2.2} color="#ef8a4a" distance={6} />}
    </>
  )
}

export default function StatueViewer() {
  const [autoRotate, setAutoRotate] = useState(false)
  const [daylight, setDaylight] = useState(false)
  const [showInfo, setShowInfo] = useState(true)

  return (
    <main className="museum-shell">
      <div className="scene-backdrop" />
      <Canvas shadows dpr={[1, 2]} camera={{ position: [4.8, 2.6, 5.2], fov: 35 }} className="statue-canvas">
        <color attach="background" args={['#171413']} />
        <fog attach="fog" args={['#171413', 7, 14]} />
        <Suspense fallback={<Loader />}>
          <Statue autoRotate={autoRotate} daylight={daylight} />
          <ContactShadows position={[0, -0.03, 0]} opacity={0.6} scale={7} blur={2.5} far={4} color="#080606" />
          <Environment preset={daylight ? 'studio' : 'warehouse'} environmentIntensity={daylight ? 0.6 : 0.25} />
        </Suspense>
      </Canvas>

      <header className="viewer-header">
        <div className="brand-lockup"><span className="brand-mark">博物</span><span>THE SILK ROAD ARCHIVE</span></div>
        <div className="header-status"><span className="status-dot" /> DIGITAL COLLECTION / 001</div>
      </header>

      <section className="hero-copy" aria-labelledby="artifact-title">
        <p className="eyebrow">QIN DYNASTY · 210 BCE</p>
        <h1 id="artifact-title">The Terracotta<br /><em>Warrior</em></h1>
        <p className="hero-description">An ancient guardian, preserved in silence. Explore every contour of a soldier from the First Emperor&apos;s underground army.</p>
      </section>

      <aside className={`info-panel ${showInfo ? '' : 'is-hidden'}`} aria-label="Artifact information">
        <div className="panel-kicker"><Info size={13} /> OBJECT RECORD</div>
        <div className="record-grid"><span>MEDIUM</span><strong>Painted terracotta</strong><span>ORIGIN</span><strong>Lintong, Shaanxi</strong><span>HEIGHT</span><strong>183 cm</strong><span>COLLECTION</span><strong>Emperor Qinshihuang&apos;s Mausoleum</strong></div>
        <div className="panel-foot"><span>SCAN RESOLUTION</span><span>8K · OBJ</span></div>
      </aside>

      <nav className="viewer-controls" aria-label="Viewer controls">
        <button className="control-button" onClick={() => setAutoRotate(!autoRotate)} aria-label={autoRotate ? 'Pause rotation' : 'Play rotation'}>{autoRotate ? <Pause size={16} /> : <Play size={16} />}<span>{autoRotate ? 'PAUSE ROTATION' : 'AUTO ROTATE'}</span></button>
        <button className="control-button" onClick={() => setDaylight(!daylight)} aria-label="Toggle lighting preset">{daylight ? <Sun size={16} /> : <Moon size={16} />}<span>{daylight ? 'DAYLIGHT' : 'DRAMATIC'}</span></button>
        <button className="icon-button" onClick={() => setShowInfo(!showInfo)} aria-label="Toggle object record"><Info size={17} /></button>
        <button className="icon-button" onClick={() => window.dispatchEvent(new Event('resize'))} aria-label="Fit artifact"><Maximize2 size={17} /></button>
      </nav>
      <div className="gesture-hint"><RotateCcw size={14} /> DRAG TO ORBIT · SCROLL TO ZOOM</div>
    </main>
  )
}

export { StatueViewer }
