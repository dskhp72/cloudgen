import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'CloudGen — Text In. History Out.',
  description: 'CloudGen by Artifact Architects transforms cultural artifact descriptions and images into touchable 3D-printed replicas.',
  generator: 'CloudGen',
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#111111',
  userScalable: true,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className="bg-background"><body className="antialiased">{children}{process.env.NODE_ENV === 'production' && <Analytics />}</body></html>
}
